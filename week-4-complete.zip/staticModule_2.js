//let messageCount = 0;
module.exports.messageCount =0;
 
//the object to return -> could have > 1 function associated.
//module.exports.sharedMessageModule = {};
 
module.exports.passMessage = function (message) {
    console.log(this.messageCount);
   this.messageCount++;
  console.log(`Message ${this.messageCount}: ${message}`);
  return;
}
 