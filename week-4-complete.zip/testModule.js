
let petName ='';
let SabineVar =''
module.exports.SabineVar = 10;
module.exports.name = function(){
    return "Sabine";
}
module.exports.age = function() {
    return "29 (really)";
}
module.exports.setPetName = function(inComing) {
    petName = inComing;
    appendPetName();
    }
    module.exports.getPetName = function() {
        return petName;
        }
        module.exports.getSabineVar = function() {
            return this.SabineVar;
            }
/** private **/
function appendPetName(){
    petName = petName +"****";
  }


