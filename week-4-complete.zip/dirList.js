const fs = require('fs')
//read the root...
let fileDir = fs.readdirSync('./')
 
// go through .. .
fileDir.forEach(function (entry){
  console.log (entry);
  // 2: ALSO  - lets check if the current entry is a directory:
  let status = fs.lstatSync(entry)
  if(status.isDirectory()){
   console.log (entry+" is also a directory");
   //we could now also then read this directory ...
   let subFiles = fs.readdirSync(entry)
 
    subFiles.forEach(function (subEntry){
      console.log("in sub::");
      console.log (subEntry);
    })
  }//if is a directory
})//outer for each