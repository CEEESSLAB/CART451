const fs = require('fs');
const newFileContainer = 'myFiles/testDataAsync.txt';
let data = "This is a test for writing asynchronous data"+"\n";
// where do we write to and what.
fs.writeFile(newFileContainer, data, function (err){
console.log("success");
});