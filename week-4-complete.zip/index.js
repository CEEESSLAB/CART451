//add a reference to the module... 
const testModuleVar = require('./testModule');
//call the function name ... 
console.log('Results: ' + testModuleVar.name());
console.log('Results: ' + testModuleVar.age());
console.log('Results: ' + testModuleVar.getPetName());
console.log('Results: ' + testModuleVar.setPetName('Santiago'));
console.log('Results: ' + testModuleVar.getPetName());
console.log('Results: ' + testModuleVar.SabineVar);
testModuleVar.SabineVar =testModuleVar.SabineVar+20;
console.log('Results: ' + testModuleVar.SabineVar);
console.log('Results: ' + testModuleVar.getSabineVar());
//console.log('Results: ' + testModuleVar.petName);
//console.log('Results: ' + testModuleVar.appendPetName());

//use the static ...
const testModuleStat = require('./staticModule_2');
console.log(testModuleStat);
 
testModuleStat.passMessage("testMessage");
testModuleStat.passMessage("testMessage_2");
testModuleStat.passMessage("testMessage_3");
 
// next var
const testModuleStatTwo = require('./staticModule_2');
// console.log(testModuleStatTwo.passMessage());
testModuleStatTwo.passMessage("testMessage");
testModuleStatTwo.passMessage("testMessage_2");
testModuleStatTwo.passMessage("testMessage_3");


const testModuleReveal = require('./revealModule');
console.log("the closure:: ");
console.log(testModuleReveal); //the returned function (CLOSURE)
 
 
const testModuleReveal_A = testModuleReveal();
console.log("the invoked function:: ");
console.log(testModuleReveal_A);//the returned values FROM the function
testModuleReveal_A.addMessage("testMessage_A");
testModuleReveal_A.addMessage("testMessage_A_2");
testModuleReveal_A.addMessage("testMessage_A_3");
testModuleReveal_A.accessMessages();
 
 
const testModuleReveal_B = testModuleReveal();
console.log("the invoked function:: ");
console.log(testModuleReveal_B);//the returned values FROM the function
testModuleReveal_B.addMessage("testMessage_B");
testModuleReveal_B.addMessage("testMessage_B_2");
testModuleReveal_B.addMessage("testMessage_B_3");
testModuleReveal_B.accessMessages();

const testModuleClass = require('./classModule');
//using "classes" -> no we are not having to "invoke" -> gives us a REF to the base definition....
//The require statement gives you what many other languages call the base type.
console.log(testModuleClass);
 
//make two seperate instances..
let instA = new testModuleClass();
console.log(instA);
instA.passMessage("testMessage Again");
instA.passMessage("testMessageTwo Again");
instA.printMessages();
console.log(instA);
 
 
let instB = new testModuleClass();
console.log(instB);
instB.passMessage("testMessageOnB Again");
instB.printMessages();
console.log(instB);