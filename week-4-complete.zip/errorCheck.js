/*Simple sync with error example*/
const fs = require('fs')
const fileContainer = 'myFiles/notExists.txt'
 
let data = ``;
 
try {
 data = fs.readFileSync(fileContainer);
 console.log(data)
 
} catch (err) {
 // Here you get the errors
 console.log("standard message: "+ err.message);
 console.log("standard name: "+ err.name);
 console.log(err);
 
}