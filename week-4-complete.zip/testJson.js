
const fs = require('fs');
let jsonFile = "./person-1.json";
 
//USING BLOCKING FUNCTION ...
console.log("start");
let rawdata = fs.readFileSync(jsonFile);
console.log("RAW::")
console.log(rawdata);
 
// parse it.
let person = JSON.parse(rawdata);
console.log("PARSED::")
console.log(person);
 
console.log('This is after the SYNCHRONOUS read call');
 
 
/* ASYNCH OPTION */
fs.readFile(jsonFile, (err, data) => {
    if (err) throw err;
    let person = JSON.parse(data);
    console.log("in asynch call back");
    console.log(person);
});
 
console.log("this is after the asynch!");
 
// third option:: use require::
 
let jsonData = require(jsonFile);
/*It works exactly like the readFileSync code we showed above,
but it is a globally available method that you can use anywhere,
which has its advantages.*/
//Require is  a * synchronous * function and is called only once
console.log("require option");
console.log(jsonData);
console.log("after the require option");