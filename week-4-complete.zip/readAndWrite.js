// const fs = require('fs');
// const filePathContainer = 'testDataAsyncNew.txt';
// let dataRead = '';
 
//  let dataToAdd  = (new Date) + " Text added to " + filePathContainer+"\n";
//  fs.writeFile(filePathContainer, dataToAdd, function(err){
//   if (err) throw err;
//   console.log("write success");
 
//  })
 
//  console.log("wrote to  the file");
 
//  fs.readFile(filePathContainer, "UTF-8", function(err, data){
//   if (err) throw err;
//   console.log(data);
//   dataRead  = data;
 
// });

const fs = require('fs');
const filePathContainer = 'testDataAsyncNew.txt';
let dataRead = '';
 
 let dataToAdd  = (new Date) + " Text added to " + filePathContainer+"\n";
 fs.writeFile(filePathContainer, dataToAdd, function(err){
  if (err) throw err;
  console.log("write success");
 
 })
 
 console.log("wrote to  the file");
 
 fs.readFile(filePathContainer, "UTF-8", function(err, data){
  if (err) throw err;
  console.log(data);
  dataRead  = data;
//MOVED
 console.log("data READ::"+ dataRead);
 
});
 
 console.log("read from the file");
 
 console.log("read from the file");
 console.log("data READ::"+ dataRead);
