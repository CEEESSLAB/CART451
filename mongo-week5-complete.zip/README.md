SO::
each server file is seperate .... each one when run using node server<x>.js sill contain different functions/prperties related to Mongo ...
server_end.js :-> is the script for receiving data from the client or a search request and will perform the necessary ops with the db to insert or retrieve the data...
NOTE:: the client.js is in the public folder :)
Questions ... contact Sabine:)
REMEMBER TO RUN `npm install ` -> to get the modules
AND  ... in the .env file PUT YOUR connection string

