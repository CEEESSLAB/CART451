/*
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/async_function
 //asynch / await -> available in es8
 //return promises just like before
 //USEs promises behind the scenes
 //looks LIKE synchronous code ... no need for .then() - 
 //you though can ONLY await INSIDE asynch functions...

*/
//window.onload = function () {
    const buttonCallJ = document.querySelector("#callbackJ");
    const responseJ = document.querySelector("#responseJ");
    
    buttonCallJ.addEventListener("click", function () {
      console.log("clicked");

      //call our asynch function
      getDataWithAsynch();

// ASYNCH FUNCTION  -- to have awaits inside
     async function getDataWithAsynch() {
    try {
        let userStr = document.querySelector("#user-string-J").value;
        const authAsynch = await checkAuth_A(userStr); // <- async operation
        const finalString = await  changeString_A(authAsynch) // <== asynch two
        responseJ.innerHTML = finalString
     }
      //return error
     catch (error) {
        console.log("reject error " +error);
      }

  };

// returns a promise
  function changeString_A(fruitString) {
    return new Promise((resolve, reject) => {
      //console.log(userString);
      setTimeout(() => {
        console.log("time-out two-a complete " + fruitString);
        let userFruitwithstars = fruitString.split("").join("*");
        resolve(userFruitwithstars);
      }, 5000); // let 5 secs go past then send back
    });
  }

//returns a promise

function checkAuth_A(userString) {
    //A:: this function will return the promise
    return new Promise((resolve, reject) => {
      console.log("Checking Auth...");
      console.log("user string:: " + userString);
  
      setTimeout(() => {
        let userFruit = "";
        console.log("time-out one-a complete " + userFruit);
        if (userString === "Sabine") {
          userFruit = "pineapple";
          resolve(userFruit);
        } else {
          userFruit = "noFruit";
          reject("error: no fruit");
        }
      }, 5000);
    });
}

}); //button

//   const setText = (text) => {
//     div.textContent = text;
//   };

//   const checkAuth = () => {
//     return new Promise((resolve, reject) => {
//       setText("Checking Auth asynch...");
//       setTimeout(() => {
//         resolve(true);
//       }, 2000);
//     });
//   };

//   const fetchUser = () => {
//     return new Promise((resolve, reject) => {
//       setText("Fetching User asynch...");
//       setTimeout(() => {
//         resolve({ name: "Max" });
//       }, 2000);
//     });
//   };

//   const checkAuthError = () => {
//     return new Promise((resolve, reject) => {
//       setText("Checking");
//       setTimeout(() => {
//         //resolve(true)
//         reject("10010");
//       }, 2000);
//     });
//   };

//   const checkAuthErrorSabs = () => {
//     return new Promise((resolve, reject) => {
//       setText("Checking Auth");
//       setTimeout(() => {
//         //resolve(true)
//         //reject("10010")
//         resolve(true);
//       }, 2000);
//     });
//   };

//   const fetchUserSabs = () => {
//     return new Promise((resolve, reject) => {
//       setText("Checking NAME");
//       setTimeout(() => {
//         resolve(true);
//         //will go to the catch ...
//         resolve({ name: "sabine" });
//       }, 2000);
//     });
//   };
//   /// to add in error handling :: because it appears asynchronous we can use try/catch ..
//   async function testSabs() {
//     try {
//       const authSabs = await checkAuthErrorSabs(); // <- async operation

//       if (authSabs) {
//         console.log("auth done");
//         //return {name:"SABInE"}
//         const user = await fetchUserSabs(); // <- async operation
//         console.log("user done");
//         return user;
//       }
//       //return error
//     } catch (error) {
//       // console.log(error);
//       return { name: "Default" };
//     }
//   }

//   mButton.addEventListener("click", function () {
//     //returned from the  try/catch block
//     testSabs().then(function (returnedVal) {
//       console.log(returnedVal);
//     }); //end then
//   });

//   button.addEventListener(
//     "click",
//     // callback is asynch...:: has to go INFRONT of function definition -
//     //becomes asynchronous
//     //tells js that one can INSIDE this function use the await keyword ... jasvascript pauses..
//     async () => {
//       //check auth() returns a promise and waits for the resolve() to happen - when it does
//       //then we get isAUth and we continue
//       const isAuth = await checkAuth();
//       let user = null;
//       if (isAuth) {
//         user = await fetchUser();
//       }
//       setText(user.name);
//     }
//   );
//};
