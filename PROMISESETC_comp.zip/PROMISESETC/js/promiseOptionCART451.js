// a promise - promises something in the future
// inside the promise is what executes ...
//resolve() - tells js that we are done and have a value
//reject() - used to throw  an  error
//promises are great because you do not need to nest the code - easier to control
//https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise
//window.onload = function () {
const buttonCallB = document.querySelector("#callbackB");
const responseB = document.querySelector("#responseB");

buttonCallB.addEventListener("click", function () {
  console.log("clicked B");

  // // FIRST the promise that we just set up using the .then()
  // checkAuth_A(document.querySelector("#user-string-B").value)
  //   // handle success....
  //   .then(function (result) {
  //     console.log(`the result from the promise is: ${result}`);
  //   });

  // // SECOND USE the promise that we just set up using the .then() AND A REJECT
  // checkAuth_A(document.querySelector("#user-string-B").value).then(
  //   // handle success....
  //   function (result) {
  //     console.log(`the result from the promise is: ${result}`);
  //   },
  //   //rejection
  //   function (rejectRes) {
  //     console.log(`the rejection from the promise is: ${rejectRes}`);
  //   }
  // );

  // //THIRD ... using the second promise
  // checkAuth_A(document.querySelector("#user-string-B").value)
  //   .then(
  //     // handle success....
  //     function (result) {
  //       console.log(`the result from the promise is: ${result}`);
  //       //returns another promise...
  //       return changeString_A(result);
  //     },
  //     //rejection
  //     function (rejectRes) {
  //       console.log(`the rejection from the promise is: ${rejectRes}`);
  //     }
  //   )
  //   //this is now the result from the changeString_A() -will run eventhough top part was rejected
  //   .then(function (result) {
  //     console.log(`the result from the promise is finally: ${result}`);
  //     responseB.innerHTML = result;
  //   });

  // //fourth ,,,,,,,
  // //catering to breaking the promise chain?
  // checkAuth_A(document.querySelector("#user-string-B").value)
  //   .then(
  //     // handle success....
  //     function (result) {
  //       console.log(`the result from the promise is: ${result}`);
  //       //returns another promise...
  //       return changeString_A(result);
  //     },
  //     //rejection
  //     function (rejectRes) {
  //       console.log(`the rejection from the promise is: ${rejectRes}`);

  //       //add a chain error
  //       return chainError("error");
  //     }
  //   )
  //   //this is now the result from the changeString_A() -will run eventhough top part was rejected
  //   .then(
  //     function (result) {
  //       console.log(`the result from the promise is finally: ${result}`);
  //       responseB.innerHTML = result;
  //     },

  //     //rejection
  //     function (rejectRes) {
  //       console.log(`the rejection is here: ${rejectRes}`);
  //     }
  //   );

//   // FIFTH :: using the catch  instead

//   checkAuth_A(document.querySelector("#user-string-B").value)
//     .then(
//       // handle success....
//       function (result) {
//         console.log(`the result from the promise is: ${result}`);
//         //returns another promise...
//         return changeString_A(result);
//       }
//       // //rejection
//       // function (rejectRes) {
//       //   console.log(`the rejection from the promise is: ${rejectRes}`);
//       // }
//     )
//     //this is now the result from the changeString_A() -will run eventhough top part was rejected
//     .then(function (result) {
//       console.log(`the result from the promise is finally: ${result}`);
//       responseB.innerHTML = result;
//     })
//     //USING CATCH it comes straight down here
//     .catch(function (error) {
//       //if error occurs in  any?

//       console.log("have incurred an error and broke the promise " + error);
//     });
 }); //button

// function chainError(err) {
//   return Promise.reject(err);
// }

/***************************************************************************** */

//THIRD we can now chain promises ... if the the function in the then()  also returns a promise object ...
//so take the changeString-A function and have it now returna prmise object

function changeString_A(fruitString) {
  return new Promise((resolve, reject) => {
    //console.log(userString);
    setTimeout(() => {
      console.log("time-out two-a complete " + fruitString);
      let userFruitwithstars = fruitString.split("").join("*");
      resolve(userFruitwithstars);
    }, 5000); // let 5 secs go past then send back
  });
}

/*** option 1: :: this function now retruns a promise  AND secondly we can then put in a reject :)/// */
//PART ONE
function checkAuth_A(userString) {
  //A:: this function will return the promise
  return new Promise((resolve, reject) => {
    console.log("Checking Auth...");
    console.log("user string:: " + userString);

     // Part ONE
     setTimeout(() => {
      let userFruit = "";
       console.log("time-out one-a complete " + userFruit);
      if (userString === "Sabine") {
        userFruit = "pineapple";
      } else {
        userFruit = "noFruit";
      }
      resolve(userFruit);

    }, 5000);

  //   // Part TWO
  //   setTimeout(() => {
  //     let userFruit = "";
  //     console.log("time-out one-a complete " + userFruit);
  //     if (userString === "Sabine") {
  //       userFruit = "pineapple";
  //       resolve(userFruit);
  //     } else {
  //       userFruit = "noFruit";
  //       reject("error: no fruit");
  //     }
  //   }, 5000);
  });
}
//};
