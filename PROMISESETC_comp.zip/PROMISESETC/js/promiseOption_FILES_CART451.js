//file access + asynch ...
//window.onload = function () {
const buttonCallC = document.querySelector("#callbackC");
const responseC = document.querySelector("#responseC");

const buttonCallD = document.querySelector("#callbackD");
const responseD = document.querySelector("#responseD");
const responseE = document.querySelector("#responseE");
const responseF = document.querySelector("#responseF");

const buttonCallG = document.querySelector("#callbackG");
const responseG = document.querySelector("#responseG");
const responseH = document.querySelector("#responseH");
const responseI = document.querySelector("#responseI");

//A LOCAL JS ...
let jsobject = {
  title: "FAVORITE LOCAL STUFF",
  favorite_veg: "asparagus",
  favorite_fruit: "watermelon",
  favorite_color: "aqua-marine",
};

buttonCallC.addEventListener("click", function () {
  console.log("clicked C");
//1 :: get a local result
  const result = formatJSObj(jsobject);
  responseC.innerHTML = result;
  // we get this immediately ... why?
  //because it is LOCAL ...
});

buttonCallD.addEventListener("click", function () {
  console.log("clicked D");
 // OPTION A
  //what if we needed to access three files but each time needed the previous result ...
    //with callbacks:
    getJsonFromServerAsync("./files/one.json", (result) => {
      let sRes = formatJSObj(result);
      responseD.innerHTML = sRes;

      getJsonFromServerAsync("./files/" + result.linkToNext, (resultB) => {
        let sResB = formatJSObj(resultB);
        responseE.innerHTML = sResB;

        getJsonFromServerAsync("./files/" + resultB.linkToNext, (resultC) => {
          let sResC = formatJSObj(resultC);
          responseF.innerHTML = sResC;
        }); //C
      }); //B
    }); //A
//OPTION B
  // using promises - turn the readJson script into returning a promise...
  getJsonFromServerPromise("./files/one.json", responseD)
    .then(
      // the resolved case
      function (result) {
        //returns another promise...
        return getJsonFromServerPromise(result, responseE);
      }
    )
    .then(
      // the resolved case
      function (result) {
        //returns another promise...
        return getJsonFromServerPromise(result, responseF);
      }
    );
}); //button click

// :: USING FETCH API
//https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API

function getJSONFromServerUsingFetch(fileNameLink) {
  // use ES6 fetch API, which return a promise
  return fetch(fileNameLink).
  then(function(r) 
  { 
    //what is returned here is ALSO A PROMISE 
    return r.json()
  })
}


/*************************** */
buttonCallG.addEventListener("click", function () {
  console.log("clicked G");

  //since what is called HAS a promise returned we must use  .then () - to get the result...
  getJSONFromServerUsingFetch("./files/one.json")
  .then(
    function (resultFromFetchA) {
      console.log(resultFromFetchA);
      let sRes =  formatJSObj(resultFromFetchA);
      responseG.innerHTML = sRes;
      return  getJSONFromServerUsingFetch("./files/"+resultFromFetchA.linkToNext)
  })

  .then(
    function (resultFromFetchB) {
      console.log(resultFromFetchB);
      let sRes =  formatJSObj(resultFromFetchB);
      responseH.innerHTML = sRes;
      return  getJSONFromServerUsingFetch("./files/"+resultFromFetchB.linkToNext)
    })

    .then(
      function (resultFromFetchC) {
        console.log(resultFromFetchC);
        let sRes =  formatJSObj(resultFromFetchC);
        responseI.innerHTML = sRes;
      })
 
}); //buttonclick

/********************* */

// format json object - helper :)
function formatJSObj(data) {
  return `
        ${data.title}
         <br />
         Fruit: ${data.favorite_fruit} <br />
         Veg: ${data.favorite_veg} <br />
        Color: ${data.favorite_color} 
        <br /> `;
}

//2: what if the object is NOT local and we need it first access from the server?
function getJsonFromServerAsync(fileName, callback) {
  //url and callback...
  return $.getJSON(`${fileName}`, callback);
}

//3:: return a promise ///
function getJsonFromServerPromise(fileString, respContainer) {
  return new Promise(function (resolve, reject) {
    $.getJSON(
      `${fileString}`,

      function (result) {
        let formatted = formatJSObj(result);
        respContainer.innerHTML = formatted;
        console.log(result.linkToNext);
        resolve("./files/" + result.linkToNext);
      }
    ); //json
  }); //promise
} //server promise

//run ...
//};
